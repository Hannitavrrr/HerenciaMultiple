package university.jala.institutional.aplicacioncompras;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

class Historial {
    private List<Comprar> compras;

    public Historial() {
        compras = new ArrayList<>();
    }

    public void agregarCompra(Comprar compra) {
        compras.add(compra);
    }

    public void mostrarComprasDelDia() {
        System.out.println("Compras del día:");
        Date hoy = new Date();
        for (Comprar compra : compras) {
            if (esHoy(compra, hoy)) {
                compra.mostrarDetalle();
            }
        }
    }

    private boolean esHoy(Comprar compra, Date hoy) {
        Date fecha = compra.getFecha();
        return fecha.getYear() == hoy.getYear() &&
               fecha.getMonth() == hoy.getMonth() &&
               fecha.getDate() == hoy.getDate();
    }
}

