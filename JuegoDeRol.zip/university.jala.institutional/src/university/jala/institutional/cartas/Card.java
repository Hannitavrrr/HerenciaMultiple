package university.jala.institutional.cartas;

class Card {
   private final Suit suit;
   private final Value value;


   public Card(Suit suit, Value value) {
       this.suit = suit;
       this.value = value;
   }


   public Suit getSuit() {
       return suit;
   }


   public Value getValue() {
       return value;
   }


   @Override
   public String toString() {
       return suit.getSymbol() + value.getSymbol();
   }
}
